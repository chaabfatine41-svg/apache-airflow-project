from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator

from datetime import datetime
import pandas as pd
import os 
import shutil

# =========================
# PATH (IMPORTANT)
# =========================
RAW_PATH = "/opt/airflow/data/raw/archive/"
PROCESSED_PATH = "/opt/airflow/data/processed/"
REPORT_PATH = "/opt/airflow/reports/"
BACKUP_PATH = "/opt/airflow/backup/"

# =========================
# 1. CHECK FILES
# =========================
def check_files():
    files = [
        "olist_orders_dataset.csv",
        "olist_order_items_dataset.csv",
        "olist_products_dataset.csv",
        "olist_customers_dataset.csv",
        "olist_order_payments_dataset.csv"
    ]

    for f in files:
        file_path = RAW_PATH + f
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Missing file: {file_path}")

# =========================
# 2. EXTRACT
# =========================
def extract_data():
    os.makedirs(PROCESSED_PATH, exist_ok=True)

    orders = pd.read_csv(RAW_PATH + "olist_orders_dataset.csv")
    items = pd.read_csv(RAW_PATH + "olist_order_items_dataset.csv")
    products = pd.read_csv(RAW_PATH + "olist_products_dataset.csv")
    customers = pd.read_csv(RAW_PATH + "olist_customers_dataset.csv")
    payments = pd.read_csv(RAW_PATH + "olist_order_payments_dataset.csv")

    orders.to_csv(PROCESSED_PATH + "orders.csv", index=False)
    items.to_csv(PROCESSED_PATH + "items.csv", index=False)
    products.to_csv(PROCESSED_PATH + "products.csv", index=False)
    customers.to_csv(PROCESSED_PATH + "customers.csv", index=False)
    payments.to_csv(PROCESSED_PATH + "payments.csv", index=False)

# =========================
# 3. CLEAN
# =========================
def clean_data():
    df = pd.read_csv(PROCESSED_PATH + "orders.csv")

    df = df.dropna()
    df = df.drop_duplicates()

    df.to_csv(PROCESSED_PATH + "clean_orders.csv", index=False)

# =========================
# 4. TRANSFORM SALES
# =========================
def transform_sales():
    orders = pd.read_csv(PROCESSED_PATH + "orders.csv")
    items = pd.read_csv(PROCESSED_PATH + "items.csv")
    products = pd.read_csv(PROCESSED_PATH + "products.csv")
    customers = pd.read_csv(PROCESSED_PATH + "customers.csv")
    payments = pd.read_csv(PROCESSED_PATH + "payments.csv")

    # Merge tables
    df = orders.merge(customers, on="customer_id")
    df = df.merge(items, on="order_id")
    df = df.merge(products, on="product_id")
    df = df.merge(payments, on="order_id")

    # KPIs
    total_sales = df["payment_value"].sum()
    total_orders = df["order_id"].nunique()
    avg_basket = total_sales / total_orders

    result = pd.DataFrame([{
        "total_sales": total_sales,
        "total_orders": total_orders,
        "avg_basket": avg_basket
    }])

    result.to_csv(PROCESSED_PATH + "sales_summary.csv", index=False)

# =========================
# 5. GENERATE REPORT
# =========================
def generate_report():
    os.makedirs(REPORT_PATH, exist_ok=True)

    df = pd.read_csv(PROCESSED_PATH + "sales_summary.csv")

    with open(REPORT_PATH + "report.txt", "w") as f:
        f.write("===== OLIST SALES REPORT =====\n\n")
        f.write(f"Total Sales: {df['total_sales'][0]}\n")
        f.write(f"Total Orders: {df['total_orders'][0]}\n")
        f.write(f"Average Basket: {df['avg_basket'][0]}\n")

# =========================
# 6. BACKUP
# =========================
def backup_report():
    os.makedirs(BACKUP_PATH, exist_ok=True)
    shutil.copy(REPORT_PATH + "report.txt", BACKUP_PATH + "report_backup.txt")

# =========================
# DAG CONFIG
# =========================
default_args = {
    "start_date": datetime(2026, 1, 1)
}

with DAG(
    dag_id="olist_sales_pipeline",
    schedule="@daily",
    catchup=False,
    default_args=default_args
) as dag:

    start = EmptyOperator(task_id="start")

    check_files_task = PythonOperator(
        task_id="check_files",
        python_callable=check_files
    )

    extract_task = PythonOperator(
        task_id="extract_data",
        python_callable=extract_data
    )

    clean_task = PythonOperator(
        task_id="clean_data",
        python_callable=clean_data
    )

    transform_task = PythonOperator(
        task_id="transform_sales",
        python_callable=transform_sales
    )

    report_task = PythonOperator(
        task_id="generate_report",
        python_callable=generate_report
    )

    backup_task = PythonOperator(
        task_id="backup",
        python_callable=backup_report
    )

    notify_task = BashOperator(
        task_id="notify",
        bash_command='echo "Pipeline ETL terminé avec succès"'
    )

    end = EmptyOperator(task_id="end")

    # =========================
    # WORKFLOW (IMPORTANT)
    # =========================
    start >> check_files_task >> extract_task >> clean_task >> transform_task >> report_task
    report_task >> backup_task >> notify_task >> end